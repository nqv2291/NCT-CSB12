from modules import*

num=int(input("Input a integer:"))

if is_prime(num):
    print(f"{num} is a prime")
else:
    print(f"{num} is not a prime")