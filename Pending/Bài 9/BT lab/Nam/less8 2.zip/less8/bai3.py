from modules import*
from itertools import count

num=int(input("Input numer:"))
prime_list=[]

for number in count(0):
    if is_prime(number):
        prime_list.append(str(number))
        if len(prime_list)==num:
            break


primes=" ".join(prime_list)
print(f"First {num} prime(s):{primes}")
