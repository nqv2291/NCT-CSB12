from modules import*
import itertools

num=int(input("Input numer:"))
prime_list=[]

for number in itertools.count(start=0):
    if is_prime(number):
        prime_list.append(str(number))
    if len(prime_list)==num:
            break

primes=" ".join(prime_list)
print(f"First {num} prime(s):{primes}")
